package com.weatherpro

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

private const val ALERT_CHANNEL_ID = "weather_alerts"
private const val ALERT_WORK_NAME = "weather_alert_monitor"

fun createAlertChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val channel = NotificationChannel(ALERT_CHANNEL_ID, "تنبيهات الطقس", NotificationManager.IMPORTANCE_HIGH)
        channel.description = "تنبيهات الأمطار والعواصف والثلوج والرياح"
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}

private fun scheduleAlerts(context: Context) {
    val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
    val request = PeriodicWorkRequestBuilder<WeatherAlertWorker>(6, TimeUnit.HOURS)
        .setConstraints(constraints).build()
    WorkManager.getInstance(context).enqueueUniquePeriodicWork(ALERT_WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
}

private fun cancelAlerts(context: Context) = WorkManager.getInstance(context).cancelUniqueWork(ALERT_WORK_NAME)

private fun getText(url: String): String {
    val connection = URL(url).openConnection() as HttpURLConnection
    connection.connectTimeout = 12000
    connection.readTimeout = 12000
    return try { connection.inputStream.bufferedReader().use { it.readText() } } finally { connection.disconnect() }
}

class WeatherAlertWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val prefs = applicationContext.getSharedPreferences("weatherpro", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("alerts_enabled", false)) return@withContext Result.success()
            val city = prefs.getString("city", null) ?: return@withContext Result.success()
            val encoded = URLEncoder.encode(city, "UTF-8")
            val geo = JSONObject(getText("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=ar&format=json"))
            val place = geo.optJSONArray("results")?.optJSONObject(0) ?: return@withContext Result.retry()
            val lat = place.getDouble("latitude"); val lon = place.getDouble("longitude")
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=weather_code,wind_speed_10m&daily=weather_code,precipitation_probability_max,precipitation_sum&forecast_days=2&timezone=auto"
            val json = JSONObject(getText(url))
            val current = json.getJSONObject("current")
            val daily = json.getJSONObject("daily")
            val code = current.optInt("weather_code", 0)
            val wind = current.optDouble("wind_speed_10m", 0.0)
            val rainChance = daily.getJSONArray("precipitation_probability_max").optInt(0, 0)
            val rainMm = daily.getJSONArray("precipitation_sum").optDouble(0, 0.0)
            val todayCode = daily.getJSONArray("weather_code").optInt(0, code)
            val alerts = mutableListOf<Pair<String, String>>()
            if (prefs.getBoolean("alert_rain", true) && rainChance >= 70 && rainMm >= 15.0)
                alerts += "أمطار غزيرة محتملة" to "احتمال الهطول $rainChance% وكمية متوقعة نحو ${rainMm.toInt()} مم في $city"
            if (prefs.getBoolean("alert_storm", true) && (code in 95..99 || todayCode in 95..99))
                alerts += "عواصف رعدية" to "تشير بيانات الطقس إلى احتمال عواصف رعدية في $city"
            if (prefs.getBoolean("alert_snow", true) && (todayCode in 71..77 || todayCode in 85..86))
                alerts += "تساقط الثلوج" to "توجد إشارة إلى تساقط الثلوج في $city"
            if (prefs.getBoolean("alert_wind", true) && wind >= 60.0)
                alerts += "رياح شديدة" to "سرعة الرياح الحالية نحو ${wind.toInt()} كم/س في $city"
            createAlertChannel(applicationContext)
            val allowed = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (allowed) alerts.forEach { (title, body) ->
                val today = java.time.LocalDate.now().toString()
                val key = "sent_${title}_$today"
                if (prefs.getBoolean(key, false).not()) {
                    val notification = NotificationCompat.Builder(applicationContext, ALERT_CHANNEL_ID)
                        .setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle(title)
                        .setContentText(body).setStyle(NotificationCompat.BigTextStyle().bigText(body))
                        .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build()
                    NotificationManagerCompat.from(applicationContext).notify(title.hashCode(), notification)
                    prefs.edit().putBoolean(key, true).apply()
                }
            }
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }
}

@Composable
fun AlertsScreen(city: String) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("weatherpro", Context.MODE_PRIVATE) }
    var enabled by remember { mutableStateOf(prefs.getBoolean("alerts_enabled", false)) }
    var rain by remember { mutableStateOf(prefs.getBoolean("alert_rain", true)) }
    var storm by remember { mutableStateOf(prefs.getBoolean("alert_storm", true)) }
    var snow by remember { mutableStateOf(prefs.getBoolean("alert_snow", true)) }
    var wind by remember { mutableStateOf(prefs.getBoolean("alert_wind", true)) }
    LazyColumn(Modifier.fillMaxSize().background(Color(0xFF071321)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("تنبيهات الطقس", color = Color(0xFFF3F8FC), fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("تنبيهات للمدينة التي تبحث عنها. اختر أنواع الطقس التي تريد متابعتها.", color = Color(0xFF9BB1C5), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            if (city.isBlank()) Text("ابحث عن مدينة أولاً حتى نتمكن من مراقبة طقسها.", color = Color(0xFF55C7F3), modifier = Modifier.padding(top = 12.dp))
        }
        item { AlertToggle("تفعيل التنبيهات", "مراقبة دورية للطقس في الخلفية", enabled) { value ->
            enabled = value; prefs.edit().putBoolean("alerts_enabled", value).apply()
            if (value && prefs.getString("city", null) != null) scheduleAlerts(context) else cancelAlerts(context)
        } }
        item { AlertToggle("🌧️ أمطار غزيرة", "احتمال ≥ 70% وكمية يومية ≥ 15 مم", rain) { rain = it; prefs.edit().putBoolean("alert_rain", it).apply() } }
        item { AlertToggle("⛈️ عواصف رعدية", "عند ظهور مؤشرات العواصف في التوقعات", storm) { storm = it; prefs.edit().putBoolean("alert_storm", it).apply() } }
        item { AlertToggle("❄️ تساقط الثلوج", "عند توقع الثلوج لليوم", snow) { snow = it; prefs.edit().putBoolean("alert_snow", it).apply() } }
        item { AlertToggle("💨 رياح شديدة", "عندما تبلغ سرعة الرياح الحالية 60 كم/س", wind) { wind = it; prefs.edit().putBoolean("alert_wind", it).apply() } }
        item { Text("يفحص التطبيق البيانات تقريباً كل 6 ساعات عند توفر الإنترنت. قد يتأخر التنفيذ بسبب توفير البطارية وقيود Android. التنبيهات إرشادية وليست بديلاً عن التحذيرات الرسمية.", color = Color(0xFF9BB1C5), fontSize = 12.sp, modifier = Modifier.padding(vertical = 12.dp)) }
    }
}

@Composable
private fun AlertToggle(title: String, detail: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Surface(color = Color(0xFF102438), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color(0xFFF3F8FC), fontWeight = FontWeight.SemiBold)
                Text(detail, color = Color(0xFF9BB1C5), fontSize = 11.sp)
            }
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}
