package com.weatherpro

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
private val Bg = Color(0xFF071321)
private val Panel = Color(0xFF102438)
private val Accent = Color(0xFF55C7F3)
private val Muted = Color(0xFF9BB1C5)
private val White = Color(0xFFF3F8FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createAlertChannel(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 410)
        setContent { WeatherProApp() }
    }
}

data class DayForecast(val date: String, val max: Double, val min: Double, val rain: Double, val code: Int, val longRange: Boolean = false)
data class WeatherData(
    val city: String, val country: String, val temp: Double, val feels: Double,
    val humidity: Int, val wind: Double, val code: Int, val days: List<DayForecast>
)

private fun httpGet(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 12000
    c.readTimeout = 12000
    c.setRequestProperty("User-Agent", "WeatherProAndroid/1.0")
    return try { c.inputStream.bufferedReader().use { it.readText() } }
    finally { c.disconnect() }
}

private suspend fun fetchWeather(query: String): WeatherData = withContext(Dispatchers.IO) {
    val q = URLEncoder.encode(query, "UTF-8")
    val geo = JSONObject(httpGet("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=ar&format=json"))
    val result = geo.optJSONArray("results")?.optJSONObject(0) ?: error("لم يتم العثور على المدينة")
    val lat = result.getDouble("latitude")
    val lon = result.getDouble("longitude")
    val city = result.optString("name", query)
    val country = result.optString("country", "")
    val raw = JSONObject(httpGet(
        "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m" +
        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
        "&forecast_days=16&timezone=auto"
    ))
    val cur = raw.getJSONObject("current")
    val daily = raw.getJSONObject("daily")
    val dates = daily.getJSONArray("time")
    val maxs = daily.getJSONArray("temperature_2m_max")
    val mins = daily.getJSONArray("temperature_2m_min")
    val rains = daily.getJSONArray("precipitation_probability_max")
    val codes = daily.getJSONArray("weather_code")
    val shortDays = (0 until dates.length()).map { i ->
        DayForecast(dates.getString(i), maxs.getDouble(i), mins.getDouble(i),
            rains.optDouble(i, 0.0), codes.getInt(i))
    }

    // EC46 ensemble-based sub-seasonal guidance extends globally to 46 days.
    // It is lower-resolution and less locally precise than the short-range forecast.
    val extendedDays = try {
        val seasonalUrl = "https://seasonal-api.open-meteo.com/v1/seasonal?latitude=$lat&longitude=$lon" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code" +
            "&forecast_days=30&timezone=auto&models=ecmwf_ec46"
        val seasonal = JSONObject(httpGet(seasonalUrl)).getJSONObject("daily")
        val st = seasonal.getJSONArray("time")
        val smax = seasonal.getJSONArray("temperature_2m_max")
        val smin = seasonal.getJSONArray("temperature_2m_min")
        val srain = seasonal.getJSONArray("precipitation_sum")
        val scode = seasonal.getJSONArray("weather_code")
        (shortDays.size until minOf(30, st.length())).map { i ->
            DayForecast(st.getString(i), smax.optDouble(i, Double.NaN),
                smin.optDouble(i, Double.NaN), srain.optDouble(i, 0.0),
                scode.optInt(i, 3), longRange = true)
        }
    } catch (_: Exception) {
        emptyList()
    }
    val days = shortDays + extendedDays
    WeatherData(city, country, cur.getDouble("temperature_2m"),
        cur.getDouble("apparent_temperature"), cur.getInt("relative_humidity_2m"),
        cur.getDouble("wind_speed_10m"), cur.getInt("weather_code"), days)
}

private fun condition(code: Int): String = when (code) {
    0 -> "سماء صافية"
    1, 2 -> "غائم جزئياً"
    3 -> "غائم"
    45, 48 -> "ضباب"
    in 51..67 -> "رذاذ أو أمطار"
    in 71..77 -> "ثلوج"
    in 80..82 -> "زخات مطر"
    in 85..86 -> "زخات ثلج"
    in 95..99 -> "عواصف رعدية"
    else -> "حالة جوية متغيرة"
}
private fun emoji(code: Int) = when {
    code == 0 -> "☀️"
    code in 1..3 -> "⛅"
    code in 45..48 -> "🌫️"
    code in 51..67 || code in 80..82 -> "🌧️"
    code in 71..77 || code in 85..86 -> "❄️"
    code >= 95 -> "⛈️"
    else -> "🌤️"
}

@Composable
fun WeatherProApp() {
    var query by remember { mutableStateOf("") }
    var weather by remember { mutableStateOf<WeatherData?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel,
        onBackground = White, onSurface = White)) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("WEATHER PRO", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("الطقس حول العالم", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).background(Panel, RoundedCornerShape(16.dp)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(value = query, onValueChange = { query = it }, modifier = Modifier.weight(1f), singleLine = true,
                    decorationBox = { inner -> Box {
                        if (query.isEmpty()) Text("ابحث عن مدينة أو دولة...", color = Muted)
                        inner()
                    } }, textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 16.sp))
                IconButton(onClick = {
                    if (query.isNotBlank()) {
                        loading = true; error = null
                        scope.launch {
                            try { weather = fetchWeather(query); getSharedPreferences("weatherpro", MODE_PRIVATE).edit().putString("city", query).apply(); tab = 0 }
                            catch (e: Exception) { error = e.message ?: "تعذر تحميل البيانات" }
                            finally { loading = false }
                        }
                    }
                }) { Icon(Icons.Default.Search, contentDescription = "بحث", tint = Accent) }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Accent)
            error?.let { Text(it, color = Color(0xFFFF8A80), modifier = Modifier.padding(16.dp)) }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TabChip("الحالة", tab == 0) { tab = 0 }
                TabChip("الرادار", tab == 1) { tab = 1 }
                TabChip("30 يوماً", tab == 2) { tab = 2 }
                TabChip("التنبيهات", tab == 3) { tab = 3 }
            }
            when (tab) {
                1 -> RadarScreen()
                2 -> ForecastScreen(weather)
                3 -> AlertsScreen(query)
                else -> CurrentScreen(weather) {
                    if (query.isNotBlank()) {
                        loading = true
                        scope.launch {
                            try { weather = fetchWeather(query); getSharedPreferences("weatherpro", MODE_PRIVATE).edit().putString("city", query).apply(); error = null }
                            catch (e: Exception) { error = e.message }
                            finally { loading = false }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, color = if (selected) Accent.copy(alpha = .18f) else Panel,
        shape = RoundedCornerShape(30.dp), border = if (selected) BorderStroke(1.dp, Accent) else null) {
        Text(label, color = if (selected) Accent else Muted, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), fontSize = 13.sp)
    }
}

@Composable
fun CurrentScreen(data: WeatherData?, onRefresh: () -> Unit) {
    if (data == null) {
        Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) {
            Text("ابحث عن مدينتك لعرض حالة الطقس والتوقعات.", color = Muted, textAlign = TextAlign.Center, fontSize = 17.sp)
        }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${data.city}، ${data.country}", color = White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text(emoji(data.code), fontSize = 58.sp, modifier = Modifier.padding(top = 8.dp))
                    Text("${data.temp.toInt()}°", color = White, fontSize = 66.sp, fontWeight = FontWeight.Light)
                    Text(condition(data.code), color = Accent, fontSize = 17.sp)
                    Text("المحسوسة ${data.feels.toInt()}°", color = Muted, modifier = Modifier.padding(top = 6.dp))
                    OutlinedButton(onClick = onRefresh, modifier = Modifier.padding(top = 12.dp)) {
                        Icon(Icons.Default.Refresh, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("تحديث")
                    }
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("الرطوبة", "${data.humidity}%", Modifier.weight(1f))
            MetricCard("الرياح", "${data.wind.toInt()} كم/س", Modifier.weight(1f))
        } }
        item { Text("نظرة سريعة", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        items(data.days.take(5)) { DayRow(it) }
        item { Text("المصادر: Open-Meteo وECMWF. الدقة تختلف حسب الموقع والمدة؛ بيانات Open-Meteo تتطلب الإسناد إلى المصدر.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 24.dp)) }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Muted, fontSize = 13.sp)
            Text(value, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
fun DayRow(day: DayForecast) {
    Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(day.date, color = Muted, modifier = Modifier.weight(1.3f), fontSize = 13.sp)
            Text(emoji(day.code), fontSize = 22.sp, modifier = Modifier.weight(.6f))
            Text("${day.max.toInt()}° / ${day.min.toInt()}°", color = White, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
            Text(if (day.longRange) "💧 ${"%.1f".format(day.rain)} مم" else "💧 ${day.rain.toInt()}%",
                color = Accent, modifier = Modifier.weight(.8f), textAlign = TextAlign.End, fontSize = 12.sp)
        }
    }
}

@Composable
fun ForecastScreen(data: WeatherData?) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("توقعات 30 يوماً", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("الأيام القريبة: توقعات تشغيلية. الأيام 17–30: إرشاد بعيد المدى من نموذج ECMWF EC46 التجميعي، بدقة مكانية أقل.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
        }
        if (data == null) item { Text("ابحث عن مدينة أولاً لعرض التوقعات.", color = Muted) }
        else {
            items(data.days) { DayRow(it) }
            if (data.days.size < 30) item {
                Text("لم تتوفر بيانات النموذج البعيد لهذه الأيام في هذا التحديث. أعد المحاولة لاحقاً.",
                    color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
            }
            item { Text("الأيام 17–30 إرشاد احتمالي من نموذج تجميعي، وليست توقعاً محلياً دقيقاً أو تحذيراً جوياً. الهطول معروض بالملليمتر لا كنسبة احتمال.",
                color = Accent, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp)) }
        }
    }
}

@Composable
fun RadarScreen() {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text("رادار الهطول", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("طبقة رادار الأمطار العالمية عبر RainViewer • حرّك الخريطة وكبّرها", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
        AndroidView(modifier = Modifier.fillMaxWidth().weight(1f), factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = WebViewClient()
                loadDataWithBaseURL("https://openstreetmap.org", radarHtml, "text/html", "UTF-8", null)
            }
        })
        Text("الرادار يعرض صور الهطول المتاحة حديثاً، وليس تنبؤاً شهرياً.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 10.dp))
    }
}

private val radarHtml = """
<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>html,body,#map{height:100%;margin:0;background:#071321}.leaflet-control-attribution{font-size:9px}</style>
</head><body><div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const map=L.map('map').setView([20,0],2);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:10,attribution:'© OpenStreetMap'}).addTo(map);
fetch('https://api.rainviewer.com/public/weather-maps.json').then(r=>r.json()).then(d=>{
 const frames=(d.radar&&d.radar.past)||[];
 if(frames.length){const f=frames[frames.length-1];
 L.tileLayer(d.host+f.path+'/256/{z}/{x}/{y}/2/1_1.png',{tileSize:256,opacity:.65,maxZoom:10,attribution:'Radar © RainViewer'}).addTo(map);}
}).catch(()=>{});
</script></body></html>
""".trimIndent()
